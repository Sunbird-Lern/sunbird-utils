#!/bin/sh
cd `dirname $0`
ROOT_PATH=`pwd`
java -Dtalend.component.manager.m2.repository=$ROOT_PATH/../lib -Xms256M -Xmx1024M -cp .:$ROOT_PATH:$ROOT_PATH/../lib/routines.jar:$ROOT_PATH/../lib/cassandra-driver-core-3.0.0-shaded.jar:$ROOT_PATH/../lib/dom4j-1.6.1.jar:$ROOT_PATH/../lib/log4j-1.2.17.jar:$ROOT_PATH/../lib/metrics-core-3.1.2.jar:$ROOT_PATH/../lib/slf4j-api-1.7.7.jar:$ROOT_PATH/../lib/talend-cassandra-1.2.jar:$ROOT_PATH/../lib/talendcsv.jar:$ROOT_PATH/rjpilotuserorgmigration_0_1.jar: stage.rjpilotuserorgmigration_0_1.RJPilotUserOrgMigration  "$@"